###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################


#packages required for analyses
library('tidyverse')
library('cowplot')
library('aster')
library('lme4')
library('lmerTest')
library('emmeans')
library('car')



#Aster Analysis using total biomass and survival data
#initial loading and prodding of data

#Load in data
data <- read.csv('greenhouse_results.csv')


#Remove replicates that failed to emerge after planting
data <- data[data$Seedling.emergence.failure!='x',]

#ensure that variables are factors
data$Genotype <- as.factor(data$Genotype)
data$Population <- as.factor(data$Population)
data$Salinity <- as.factor(data$Salinity)
data$Microbes <- as.factor(data$Microbes)
data$History <- as.factor(data$History)


#Relabel above and belowground biomass variables to ease workflow
colnames(data)[10] <- 'Shoots'
colnames(data)[11] <- 'Roots'

#Generate new variable, total biomass
data$Total <- data$Shoots+data$Roots
data$Total <- sqrt(data$Total)

#Create dummy variable including all factors
data$Comp <- factor(paste(data$History,data$Salinity,data$Microbes))

#Converts replicates that died to 0, and replicates that survived to 1
data$Death <- as.character(data$Death)
data[data$Death=='x',]$Death <- 0
data[data$Death=='',]$Death <- 1
data$Death <- as.numeric(data$Death)

#set Death as a factor and rename for clarity
data <- data %>% 
  mutate(surv = as.factor(Death))


###############################################################
###############################################################
#The following section constructs and evaluates the aster model

data_clean <- data %>%
  filter(!is.na(surv)  & !is.na(Total)) %>%
  mutate(surv = as.numeric(as.character(surv)),
         Total = ifelse(surv == 0, 0, Total))

#store variables upon which we'll reshape
vars <- c("surv", "Total") 

#reshape to long format
data_aster <- reshape(data_clean, varying = list(vars), 
                      direction = "long", timevar = "varb", 
                      times = as.factor(vars), v.names = "resp")

data_aster <- data.frame(data_aster, root = 1)




#Add root to dataframe
data_aster$root <- 1

#Specify the predecessor and family structure
pred <- c(0,1) 

#Generate distribution for total biomass
hist(subset(data_clean, surv == 1)$Total)
total_sd <- sd(subset(data_clean, surv == 1)$Total)


# assign distribution families to life history stages
fam <- c(1,2)
famlist <- list(fam.bernoulli(), fam.normal.location(total_sd))


# Adding psuedo-covariates for total biomass (final fitness node) in the graphical model
data_aster$fitness <- ifelse(data_aster$varb == "Total", 1, 0)


#Full aster model
aout1 <- reaster(resp ~ varb + fitness:(Salinity+Microbes+History + 
                                          Salinity:Microbes+ Salinity:History + Microbes:History+ 
                                          Salinity:Microbes:History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)



#We determined the significance of the fixed effects by using likelihood ratio tests, 
#comparing sequentially nested models with and without the term of interest. 

#Testing specific terms
#three way interaction
aout1 <- reaster(resp ~ varb + fitness:(Salinity+Microbes+History + 
                                          Salinity:Microbes+ Salinity:History + Microbes:History+ 
                                          Salinity:Microbes:History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
aout2 <- reaster(resp ~ varb + fitness:(Salinity+Microbes+History + 
                                          Salinity:Microbes+ Salinity:History + Microbes:History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
anova(aout2, aout1)
#two way interactions
aout1 <- reaster(resp ~ varb + fitness:(Salinity+Microbes+History + 
                                          Salinity:Microbes+ Salinity:History + Microbes:History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
aout2 <- reaster(resp ~ varb + fitness:(Salinity+Microbes+History + 
                                          Salinity:History + Microbes:History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
anova(aout2, aout1)

aout1 <- reaster(resp ~ varb + fitness:(Salinity+Microbes+History + 
                                          Salinity:Microbes+ Salinity:History + Microbes:History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
aout2 <- reaster(resp ~ varb + fitness:(Salinity+Microbes+History + 
                                          Salinity:Microbes+ Microbes:History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
anova(aout2, aout1)

aout1 <- reaster(resp ~ varb + fitness:(Salinity+Microbes+History + 
                                          Salinity:Microbes+ Salinity:History + Microbes:History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
aout2 <- reaster(resp ~ varb + fitness:(Salinity+Microbes+History + 
                                          Salinity:Microbes+ Salinity:History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
anova(aout2, aout1)

#single terms

aout1 <- reaster(resp ~ varb + fitness:(Salinity+Microbes+History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
aout2 <- reaster(resp ~ varb + fitness:(Salinity+Microbes),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
anova(aout2, aout1)

aout1 <- reaster(resp ~ varb + fitness:(Salinity+Microbes+History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
aout2 <- reaster(resp ~ varb + fitness:(Salinity+History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
anova(aout2, aout1)

aout1 <- reaster(resp ~ varb + fitness:(Salinity+Microbes+History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
aout2 <- reaster(resp ~ varb + fitness:(Microbes+History),
                 list(Population = ~ 0 + fitness:Population),
                 pred, fam, varb, id, root, data = data_aster, famlist = famlist)
anova(aout2, aout1)





#As there were significant interactions with the microbial treatments,
#we subsequently used a priori comparisons to evaluate the effects of microbes on local adaptation
#Namely, within each combination of inoculum and greenhouse salinity,
#we compared our estimated fitness measure (aster model, biomass and survival) 
#between the 2 historical source salinity habitats. 
#Adaptation to the local salinity environment would be supported if, for a given greenhouse salinity treatment, 
#we observed the highest fitness in plants whose historical salinity environment matched the greenhouse salinity treatment 
#(e.g., saline plants with saline treatment, and nonsaline plants with nonsaline treatment).

levels(data_aster$Comp)
c1 <- c(0,1,0,0,0,0,0,-1,0,0,0,0)#Comparison 1-Between saline and nonsaline population: Under nonsaline env and saline inoculum
c2 <- c(0,0,0,0,1,0,0,0,0,0,-1,0)#Comparison 2-Between saline and nonsaline population: Under saline env and saline inoculum
c3 <- c(1,0,0,0,0,0,-1,0,0,0,0,0)#Comparison 3-Between saline and nonsaline population: Under nonsaline env and nonsaline inoculum
c4 <- c(0,0,0,1,0,0,0,0,0,-1,0,0)#Comparison 4-Between saline and nonsaline population: Under saline env and nonsaline inoculum
c5 <- c(0,0,1,0,0,0,0,0,-1,0,0,0)#Comparison 5-Between saline and nonsaline population: Under nonsaline env and sterile inoculum
c6 <- c(0,0,0,0,0,1,0,0,0,0,0,-1)#Comparison 6-Between saline and nonsaline population: Under saline env and sterile inoculum

mat <- cbind(c1,c2,c3,c4,c5,c6)

contrasts(data_aster$Comp) <- mat



#Users will note that in the following code this warning message will be given: "contrasts dropped from factor Comp due to missing levels"
#This warning message appears because this code is individually showing each contrasts by subsetting the data.
#Hence, when the data is subset, some of the levels from the models are missing 
#We subset the data so it is easier to see the relevant contrasts individually
#This does not alter the outcome of the analysis

#Comparison1: Between saline and nonsaline population: Under nonsaline env and saline inoculum
summary(reaster(resp ~ varb + fitness:Comp,
                 list(Population =~ 0+fitness:Population),
                 pred, fam, varb, id, root,  famlist = famlist,
                 data = data_aster[data_aster$Salinity=='Nonsaline' & data_aster$Microbes=='Saline',]))
#Comparison2: Between saline and nonsaline population: Under saline env and saline inoculum
summary(reaster(resp ~ varb + fitness:Comp,
                list(Population =~ 0+fitness:Population),
                pred, fam, varb, id, root,  famlist = famlist,
                data = data_aster[data_aster$Salinity=='Saline' & data_aster$Microbes=='Saline',]))
#Comparison3: Between saline and nonsaline population: Under nonsaline env and nonsaline inoculum
summary(reaster(resp ~ varb + fitness:Comp,
                list(Population =~ 0+fitness:Population),
                pred, fam, varb, id, root,  famlist = famlist,
                data = data_aster[data_aster$Salinity=='Nonsaline' & data_aster$Microbes=='Nonsaline',]))
#Comparison4: Between saline and nonsaline population: Under saline env and nonsaline inoculum
summary(reaster(resp ~ varb + fitness:Comp,
                list(Population =~ 0+fitness:Population),
                pred, fam, varb, id, root,  famlist = famlist,
                data = data_aster[data_aster$Salinity=='Saline' & data_aster$Microbes=='Nonsaline',]))
#Comparison5: Between saline and nonsaline population: Under nonsaline env and sterile inoculum
summary(reaster(resp ~ varb + fitness:Comp,
                list(Population =~ 0+fitness:Population),
                pred, fam, varb, id, root,  famlist = famlist,
                data = data_aster[data_aster$Salinity=='Nonsaline' & data_aster$Microbes=='Sterile',]))
#Comparison6: Between saline and nonsaline population: Under saline env and sterile inoculum
summary(reaster(resp ~ varb + fitness:Comp,
                list(Population =~ 0+fitness:Population),
                pred, fam, varb, id, root,  famlist = famlist,
                data = data_aster[data_aster$Salinity=='Saline' & data_aster$Microbes=='Sterile',]))






#Model predictions by population 
aster.pred <- data_aster
aout1 <- aster(resp ~ varb + fitness:(Salinity+Microbes+History + Population + 
                                        Salinity:Microbes+ Salinity:Population:History + Microbes:Population:History+ 
                                        Salinity:Microbes:Population:History + History/Population),
               pred, fam, varb, id, root, data = data_aster, famlist = famlist)


#fixed model predictions
fit.p <- predict(aout1, se.fit = T, model.type = "unconditional")

aster.pred$fit <- fit.p$fit
aster.pred$se <- fit.p$se.fit
#summarize unconditional lifetime fitness (biomass)

aster_sum <- aster.pred %>%
  group_by(varb, History, Salinity, Microbes,Population) %>%
  summarise(
    estimate = mean(fit), 
    estimate.se = mean(se)) %>%
  filter(varb == "Total") %>%
  ungroup() %>%
  mutate(varb = "fitness")
aster_sum <- data.frame(aster_sum)
aster_sum


#Model predictions by treatment 
aster.pred <- data_aster
aout1 <- aster(resp ~ varb + fitness:(Salinity+Microbes+History + 
                                        Salinity:Microbes+ Salinity:History + Microbes:History+ 
                                        Salinity:Microbes:History + Population),
               pred, fam, varb, id, root, data = data_aster, famlist = famlist)


#fixed model predictions
fit.p <- predict(aout1, se.fit = T, model.type = "unconditional")

aster.pred$fit <- fit.p$fit
aster.pred$se <- fit.p$se.fit
#summarize unconditional lifetime fitness (biomass)

aster_sum <- aster.pred %>%
  group_by(varb, History, Salinity, Microbes) %>%
  summarise(
    estimate = mean(fit), 
    estimate.se = mean(se)) %>%
  filter(varb == "Total") %>%
  ungroup() %>%
  mutate(varb = "fitness")
aster_sum <- data.frame(aster_sum)
aster_sum






###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
#Individual analysis above and belowground biomass (excluding dead plants)

#Load in data
data <- read.csv('greenhouse_results.csv')

#Remove replicates that failed to emerge after planting
data <- data[data$Seedling.emergence.failure!='x',]

#ensure that variables are factors
data$Genotype <- as.factor(data$Genotype)
data$Population <- as.factor(data$Population)
data$Salinity <- as.factor(data$Salinity)
data$Microbes <- as.factor(data$Microbes)
data$History <- as.factor(data$History)

#Relabel above and belowground biomass variables to ease workflow
colnames(data)[10] <- 'Shoots'
colnames(data)[11] <- 'Roots'



#Converts replicates that died to 0, and replicates that survived to 1
data$Death <- as.character(data$Death)
data[data$Death=='x',]$Death <- 0
data[data$Death=='',]$Death <- 1
data$Death <- as.numeric(data$Death)

data <- data %>% 
  mutate(surv = as.factor(Death))




data_clean <- data %>%
  filter(!is.na(surv)  & !is.na(Shoots)) %>%
  mutate(surv = as.numeric(as.character(surv)),
         Shoots = ifelse(surv == 0, 0, Shoots))


#Removes dead plants
data_clean <- data_clean[data_clean$surv!=0,]


#Aboveground model, maternal line as random effect
mod.shoot <- lmer(sqrt(Shoots)~Salinity*Microbes*History + (1|Genotype), data=data_clean)
anova(mod.shoot)

#Aboveground model, population as random effect
mod.shoot <- lmer(sqrt(Shoots)~Salinity*Microbes*History + (1|Population), data=data_clean)
anova(mod.shoot)

#As with the aster models, we  used a priori comparisons to evaluate 
#the effects of microbes on local adaptation
#Contrasts are in the following order
#Comparison 1-Between saline and nonsaline population: Under nonsaline env and saline inoculum
#Comparison 2-Between saline and nonsaline population: Under saline env and saline inoculum
#Comparison 3-Between saline and nonsaline population: Under nonsaline env and nonsaline inoculum
#Comparison 4-Between saline and nonsaline population: Under saline env and nonsaline inoculum
#Comparison 5-Between saline and nonsaline population: Under nonsaline env and sterile inoculum
#Comparison 6-Between saline and nonsaline population: Under saline env and sterile inoculum
emm_mod <- emmeans(mod.shoot, ~ Salinity*Microbes*History,type='response')
contr_mat <- coef(pairs(emm_mod))[,c(6,17,27,36,44,51)+3]
emmeans(mod.shoot, ~ Salinity*Microbes*History, contr = contr_mat, adjust = "none")



#Belowground model, maternal line as random effect
mod.root <- lmer(sqrt(Roots)~Salinity*Microbes*History + (1|Genotype), data=data_clean)
anova(mod.root)

#Belowground model, population as random effect
mod.root <- lmer(sqrt(Roots)~Salinity*Microbes*History + (1|Population), data=data_clean)
anova(mod.root)

#As with the aster models, we  used a priori comparisons to evaluate 
#the effects of microbes on local adaptation
#Contrasts are in the following order
#Comparison 1-Between saline and nonsaline population: Under nonsaline env and saline inoculum
#Comparison 2-Between saline and nonsaline population: Under saline env and saline inoculum
#Comparison 3-Between saline and nonsaline population: Under nonsaline env and nonsaline inoculum
#Comparison 4-Between saline and nonsaline population: Under saline env and nonsaline inoculum
#Comparison 5-Between saline and nonsaline population: Under nonsaline env and sterile inoculum
#Comparison 6-Between saline and nonsaline population: Under saline env and sterile inoculum
emm_mod <- emmeans(mod.root, ~ Salinity*Microbes*History,type='response')
contr_mat <- coef(pairs(emm_mod))[,c(6,17,27,36,44,51)+3]
emmeans(mod.root, ~ Salinity*Microbes*History, contr = contr_mat, adjust = "none")






###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
###################################################################################################
#Individual analysis plant survival

#Load in data
data <- read.csv('greenhouse_results.csv')

#Remove replicates that failed to emerge after planting
data <- data[data$Seedling.emergence.failure!='x',]

#ensure that variables are factors
data$Genotype <- as.factor(data$Genotype)
data$Population <- as.factor(data$Population)
data$Salinity <- as.factor(data$Salinity)
data$Microbes <- as.factor(data$Microbes)
data$History <- as.factor(data$History)




#Converts replicates that died to 0, and replicates that survived to 1
data$Death <- as.character(data$Death)
data[data$Death=='x',]$Death <- 0
data[data$Death=='',]$Death <- 1
data$Death <- as.numeric(data$Death)


data <- data %>% 
  mutate(surv = as.factor(Death))


#Only include plants in saline treatment, as close to 100% survival in nonsaline treatments
#Including the nonsaline treatments in the models
data.s <- data[data$Salinity=='Saline',]



#Aboveground model, population as random effect
mod.surv <- glmer(Death ~ Microbes*History  + (1|Population), data = data.s, family = "binomial")
Anova(mod.surv)

#Aboveground model, maternal line as random effect
mod.surv <- glmer(Death ~ Microbes*History  + (1|Genotype), data = data.s, family = "binomial")
Anova(mod.surv)


#As with the aster models, we  used a priori comparisons to evaluate 
#the effects of microbes on local adaptation
#Contrasts are in the following order
#Comparison 1-Between saline and nonsaline population: Under saline env and saline inoculum
#Comparison 2-Between saline and nonsaline population: Under saline env and nonsaline inoculum
#Comparison 3-Between saline and nonsaline population: Under saline env and sterile inoculum
emm_mod <- emmeans(mod.surv, ~ Microbes*History,type='response')
contr_mat <- coef(pairs(emm_mod))[,c(3,8,12)+2]
emmeans(mod.surv, ~ Microbes*History, contr = contr_mat, adjust = "none",type='response')


