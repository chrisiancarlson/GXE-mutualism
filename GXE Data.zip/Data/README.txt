Project name:
How Genotype by Environment Interactions Maintain Variation in Mutualism

Contact information:
Chris Carlson
Email: christopheriancarlson@gmail.com


Executive summary:
This .zip contains data and analysis from Ricks et al. 2023, Johnson et al. 2010, and Henry et al. 2020. 


Description of files:
Henry_aceto_ovidata.csv
File containing oviposition data from Henry et al. 2010. For flies evolved in control or high sugar media with and without microbes, this spreadsheet notes the number of eggs laid per fly. 

Henry_oviposition_analysis.Rmd
File containing oviposition data from Henry et al. 2020. For flies evolved in control or high sugar media with and without microbes, this spreadsheet notes the number of eggs laid per fly. For details on exact statistical analysis see, Henry et al. 2010.  We copied means of treatments corresponding to our model's parameters directly into our python code, "GXE Reaction Norms.py" to generate our reaction norm plots. We used the statistical analysis from this notebook when stating whether differences between our payoffs was significant. 

Ricks_greenhouse_results.csv
File containing data on above and belowground plant biomass, as well as survival. These data were used in Ricks et al. to measure plant fitness in a greenhouse experiment. 

Ricks_analysis.R
Using the greenhouse_results.csv file, Ricks et al. 2023 used plant fitness metrics including above and belowground biomass, as well as survival. Ricks et al. built aster models to combine these measures to estimate fitness. We copied means from their analysis corresponding to our model's payoffs into our python code "GXE Reaction Norms.py" to generate reaction norm plots for this interaction. We used statistical analysis of the aster models in Ricks et al. to denote significant payoff differences. 


Johnson_data.csv
Data from Johnson et al. 2010 denoting plant aboveground biomass and hyphal density in their reciprocal transplant experiment. The spreadsheet denotes the origin of soil, plants, and mycorrhizal inocula from their experiment. Where A = Fermi labs, K = Konza, and C = Cedar Creek. If the site type is preceded by an S, it indicates a sterile application of inocula. We imported data directly from this spreadsheet into our python file, "GXE Reaction Norms.py" to conduct statistical analysis and generate reaction norm plots. 




